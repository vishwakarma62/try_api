import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:try_api/model/user_model.dart';


abstract class StphenKingBooksRepo {
  Future<List<dynamic>> getStphenKingBooks();
}

class StphenKingBooksRepoImpl extends StphenKingBooksRepo {
  Future<List<dynamic>> getStphenKingBooks() async {
    String url = "https://stephen-king-api.onrender.com/api/books";
    http.Response response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Map<String, dynamic> jsonData = json.decode(response.body);
      List<dynamic> body = jsonData['data'];
      return List<StphenKingBooksModels>.from(
          (body).map((e) => StphenKingBooksModels.fromJson(e)));
    } else {
      throw response.body;
    }
  }

  
}