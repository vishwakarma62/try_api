import 'dart:io';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:try_api/blocs/main/main_event.dart';
import 'package:try_api/blocs/main/main_state.dart';
import 'package:try_api/repo/main_repo.dart';


class StphenKingBooksBloc
    extends Bloc<StphenKingBooksEvent, StphenKingBooksState> {
  StphenKingBooksRepo repo;
  StphenKingBooksBloc(this.repo) : super(StphenKingBooksInitialState()) {
    on<FetchStphenKingBooksEvent>(_fetchStphenKingBooksEvent);
  }

  void _fetchStphenKingBooksEvent(FetchStphenKingBooksEvent event,
      Emitter<StphenKingBooksState> emit) async {
    try {
      emit(StphenKingBooksLoadingState());
      dynamic data = await repo.getStphenKingBooks();
      if (data != null) {
        emit(StphenKingBooksLoadedState(stphenKingBooksModels: data));
      } else {
        emit(StphenKingBooksNoDataState());
      }
    } on SocketException {
      emit(StphenKingBooksNoInternetState());
    } catch (e) {
      emit(
        StphenKingBooksErrorState(
          msg: e.toString(),
        ),
      );
    }
  }

  
}


