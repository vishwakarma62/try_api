// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:try_api/bloc/user_state.dart';
// import '../bloc/user.event.dart';
// import '../bloc/user_bloc.dart';

// class UserScreen extends StatefulWidget {
//   const UserScreen({super.key});

//   @override
//   State<UserScreen> createState() => _UserScreenState();
// }

// class _UserScreenState extends State<UserScreen> {
//   var _formKey = GlobalKey<FormState>();
//   final emailController = TextEditingController();
//   final formKey = GlobalKey<FormState>();
//   bool p_isObscure = false;
//   var passwordcontroller = TextEditingController();
//   late UserBloc userBloc;
//   TextEditingController slugCtr = TextEditingController();
//   TextEditingController titleCtr = TextEditingController();
//   TextEditingController descriptionCtr = TextEditingController();
//   TextEditingController bodyCtr = TextEditingController();

//   @override
//   void initState() {
//     userBloc = context.read<UserBloc>();

//     userBloc.add(UserSubmitEvent( ));
//       super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return BlocBuilder<UserBloc, UserState>(
//       builder: (context, state) {
//         if (state is UserNoInternetState) {
//           print('No internet');
//           return Center(
//             child: Text('No internet'),
//           );
//         }
//         if (state is UserInitialState || state is UserLoadingState) {
//           return Center(child: CircularProgressIndicator());
//         }
//         if (state is UserErrorState) {
//           print('${state.msg.toString()}');
//           return Center(child: Text(state.msg.toString()));
//         }
//         if (state is UserDoneState) {
//           print('DoneSuccess');
//           return Form(
//             key: _formKey,
//             child: Scaffold(
//               appBar: AppBar(),
//               body: SafeArea(
//                 child: SingleChildScrollView(
//                   child: Column(
//                     children: [
//                       Align(
//                         alignment: Alignment.centerLeft,
//                         child: Padding(
//                           padding: const EdgeInsets.only(top: 40, left: 30),
//                           child: Text(
//                             'Title*',
//                             style: TextStyle(
//                             fontSize: 15,
//                             fontWeight: FontWeight.w300,
//                             color: Colors.black,
//                             ),
//                           ),
//                         ),
//                       ),
//                       // SizedBox(
//                       //   height: 5,
//                       // ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 30, right: 30),
//                         child: TextFormField(
//                           controller: titleCtr,
//                           decoration: InputDecoration(
//                               border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(10)),
//                               hintText: ' Article title',
//                               hintStyle: TextStyle(color: Colors.black38),
//                               labelStyle: TextStyle(color: Colors.black87),
//                               fillColor: Colors.black87),
//                         ),
//                       ),
//                       Column(
//                         children: [
//                           Align(
//                             alignment: Alignment.centerLeft,
//                             child: Padding(
//                               padding: const EdgeInsets.only(top: 40, left: 30),
//                               child: Text(
//                                 'About*',
//                                 style: TextStyle(
//                                   fontSize: 15,
//                                   fontWeight: FontWeight.w300,
//                                   color: Colors.black,
//                                 ),
//                               ),
//                             ),
//                           ),
//                           // SizedBox(
//                           //   height: 5,
//                           // ),
//                           Padding(
//                             padding: const EdgeInsets.only(left: 30, right: 30),
//                             child: TextFormField(
//                               controller: bodyCtr,
//                               decoration: InputDecoration(  
//                                   border: OutlineInputBorder(
//                                       borderRadius: BorderRadius.circular(10)),
//                                   hintText: ' About?',
//                                   hintStyle: TextStyle(color: Colors.black38),
//                                   labelStyle: TextStyle(color: Colors.black87),
//                                   fillColor: Colors.black87),
//                             ),
//                           ),
//                           Column(
//                             children: [
//                               Align(
//                                 alignment: Alignment.centerLeft,
//                                 child: Padding(
//                                   padding:
//                                       const EdgeInsets.only(top: 40, left: 30),
//                                   child: Text(
//                                     'Your Article*',
//                                     style: TextStyle(
//                                       fontSize: 15,
//                                       fontWeight: FontWeight.w300,
//                                       color: Colors.black,
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                               // SizedBox(
//                               //   height: 5,
//                               // ),
//                               Padding(
//                                 padding:
//                                     const EdgeInsets.only(left: 30, right: 30),
//                                 child: TextFormField(
//                                   controller: descriptionCtr,
//                                   decoration: InputDecoration(
//                                       border: OutlineInputBorder(
//                                           borderRadius:
//                                               BorderRadius.circular(10)),
//                                       hintText: 'Your Article(in markdown)',
//                                       hintStyle:
//                                           TextStyle(color: Colors.black38),
//                                       labelStyle:
//                                           TextStyle(color: Colors.black87),
//                                       fillColor: Colors.black87),
//                                 ),
//                               ),
//                               Column(
//                                 children: [
//                                   Align(
//                                     alignment: Alignment.centerLeft,
//                                     child: Padding(
//                                       padding: const EdgeInsets.only(
//                                           top: 40, left: 30),
//                                       child: Text(
//                                         'Tags*',
//                                         style: TextStyle(
//                                           fontSize: 15,
//                                           fontWeight: FontWeight.w300,
//                                           color: Colors.black,
//                                         ),
//                                       ),
//                                     ),
//                                   ),
//                                   // SizedBox(
//                                   //   height: 5,
//                                   // ),
//                                   Padding(
//                                     padding: const EdgeInsets.only(
//                                         left: 30, right: 30),
//                                     child: TextFormField(
//                                       controller: bodyCtr,
//                                       decoration: InputDecoration(
//                                           border: OutlineInputBorder(
//                                               borderRadius:
//                                                   BorderRadius.circular(10)),
//                                           hintText: 'Tags',
//                                           hintStyle:
//                                               TextStyle(color: Colors.black38),
//                                           labelStyle:
//                                               TextStyle(color: Colors.black87),
//                                           fillColor: Colors.black87),
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                               SizedBox(
//                                 height: 30,
//                               ),
//                               Container(
//                                 decoration: BoxDecoration(
//                                   color: Colors.green,
//                                   borderRadius: BorderRadius.circular(10),
//                                 ),
//                                 height: 57,
//                                 width: 280,
//                                 child: MaterialButton(
//                                   onPressed: () async {
//                                     FocusManager.instance.primaryFocus!
//                                         .unfocus();
//                                     if (_formKey.currentState!.validate()) {}
//                                   },
//                                   child: Padding(
//                                     padding: const EdgeInsets.all(8.0),
//                                     child: Text(
//                                       'Sign in',
//                                       style: TextStyle(
//                                           fontSize: 20, color: Colors.white),
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           );
//         }
//         return Center(
//           child: Text('TATA '),
//         );
//       },
//     );
//   }
// }
