// class ProductListModel {

// int? id;
// String? year;
// String? title;
// String? handle;
// String? Publisher;
// String? ISBN;
// String? Pages;
// String? Notes;
// String? created_at;
// String? name;
// String? url;

// ProductListModel(
//   {
//   this.id ,
//   this.year,
//   this.title,
//   this.handle,
//   this.Publisher,
//   this.ISBN,
//   this.Pages,
//   this.Notes,
//   this.created_at,
//   this.name,
//   this.url
// });

// ProductListModel.fromjson(Map<String,dynamic>json)
// {
//     id = json['id'];
//     year =json ['year'];
//     title = json['title'];
//     handle = json ['handle'];
//     Publisher = json ['publisher'];
//     ISBN = json ['isnbn'];
//     Pages = json ['pages'];
//     Notes = json ['notes'];
//     created_at = json ['created_at'];
//     name = json ['name'];
//     url = json['url'];

// }
// }