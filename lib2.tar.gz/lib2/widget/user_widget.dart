import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:try_api/model/user_model.dart';

class StphenKingBooksWidget extends StatefulWidget {
  StphenKingBooksWidget({super.key, required this.stphenKingBooksModels});
  StphenKingBooksModels stphenKingBooksModels;

  @override
  State<StphenKingBooksWidget> createState() => _StphenKingBooksWidgetState();
}

class _StphenKingBooksWidgetState extends State<StphenKingBooksWidget>
    with TickerProviderStateMixin {
  bool isExpend = false;
  late AnimationController _controller;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () {
        
      },
      child: Card(
        color: Colors.blue.withGreen(210).withOpacity(0.5),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      "${widget.stphenKingBooksModels.title} (${widget.stphenKingBooksModels.year})",
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                          fontSize: 18),
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      setState(() {
                        isExpend = !isExpend;
                      });
                    },
                    icon: Transform.scale(
                      scale: 1,
                      child: isExpend
                          ? Icon(
                              Icons.keyboard_arrow_down_rounded,
                              color: Colors.white,
                            )
                          : Icon(
                              Icons.keyboard_arrow_up_rounded,
                              color: Colors.white,
                            ),
                    ),
                  )
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Publisher :",
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Expanded(
                    child: Text(
                      "${widget.stphenKingBooksModels.publisher}",
                      style: TextStyle(
                        color: Colors.white,
                      ),
                    ),
                  ),
                  Icon(
                    Icons.menu_book_rounded,
                    color: Colors.white,
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Text(
                    "${widget.stphenKingBooksModels.pages}",
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  )
                ],
              ),
              if (widget.stphenKingBooksModels.notes!.join(', ').isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        CupertinoIcons.arrow_turn_down_right,
                        color: Colors.white,
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Expanded(
                        child: Text(
                          "${widget.stphenKingBooksModels.notes!.join(', ')}",
                          style: TextStyle(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              if (widget.stphenKingBooksModels.villains!.isNotEmpty && isExpend)
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: Text(
                        "Villains",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                            fontSize: 16),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Wrap(
                      direction: Axis.horizontal,
                      spacing: 10,
                      runSpacing: 10,
                      children: List.generate(
                        widget.stphenKingBooksModels.villains!.length,
                        (index) => InkWell(
                          onTap: () {
                            
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 15, vertical: 5),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.black54),
                            child: Text(
                              "${widget.stphenKingBooksModels.villains![index].name}",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}