// import "dart:convert";
// import "package:http/http.dart" as http;
// import "package:try_api/model/user_model.dart";
// import "../config/constant.dart";

// class UserClient {
//   static final UserClient instance = UserClient._internal();
//   factory UserClient() {
//     return instance;
//   }

//   UserClient._internal();

//   Future<http.Response> doGet(String url, {Map<String, String>? header}) async {
//     Map<String, String> head = {
//       "content-type": "application/json",
//       "Authorization": "Bearer ${ApiConstant.TOKEN}"
//     };
//     if (header != null) {
//       head.addAll(header);
//     }
//     return http.get(Uri.parse(url), headers: head);
//   }

//   Future<http.Response> doPostArticle(String url, Map<String, dynamic> body,
//       {Map<String, String>? header}) async {
        
      
//         Map<String, String> head = {
//       "content-type": "application/json",
//       "Authorization": "Bearer ${ApiConstant.TOKEN}"
//     };

//     if (header != null) {
//       head.addAll(header);
//     }

//     UserModel newArticleModel = UserModel(
//       user: User(
//         title: body.values.first["title"],
//         description: body.values.first["description"],
//         body: body.values.first["body"],
//         tagList: body.values.first["tagList"],
//       ),
//     );

//     try {
//       http.Response response = await http.post(
//         Uri.parse(url),
//         body: jsonEncode(newArticleModel.toJson()),
//         headers: head,
//       );

//       dynamic jsonData = jsonDecode(response.body);
//       if (response.statusCode!= 403 && response.statusCode != 401) {
//         return response;
//       } else {
//         throw response.body;
//       }
//     } catch (e) {
//       throw e.toString();
//     }
//   }
// }